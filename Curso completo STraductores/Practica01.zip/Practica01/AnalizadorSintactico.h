#ifndef ANALIZADORSINTACTICO_H
#define ANALIZADORSINTACTICO_H
#include <iostream>
#include <string>
#pragma once

using namespace std;

class AnalizadorSintactico {
 public:
  explicit AnalizadorSintactico(const string &cadena);
  int get_cadena() { return reglas; }

 private:
  int reglas;
  string m_cadena;
  string sem_cadena;
  char *preanalisis;

  void coincidir(char dato);
  float term();
  float fact();
  float Resto_expr(int num);
  float digito();
  float expr();
};

#endif