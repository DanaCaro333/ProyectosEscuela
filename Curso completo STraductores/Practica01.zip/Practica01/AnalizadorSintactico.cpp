#include "AnalizadorSintactico.h"

AnalizadorSintactico::AnalizadorSintactico(const string &cadena) {
  m_cadena = cadena;
  preanalisis = &m_cadena[0];
  expr();
}

void AnalizadorSintactico::coincidir(char dato) {
  if (dato == '0' || dato == '1' || dato == '2' || dato == '3' || dato == '4' ||
      dato == '5' || dato == '6' || dato == '7' || dato == '8' || dato == '9' ||
      dato == ')') {
    preanalisis++;
    if (*preanalisis != '+' && *preanalisis != '-' && *preanalisis != '*' &&
        *preanalisis != '/' && *preanalisis != '(' && *preanalisis != ')' &&
        *preanalisis != '\00') {
      cout << "No coincide con la gramatica" << endl;
      exit;
    }
  } else if (dato == '+' || dato == '-' || dato == '*' || dato == '/' ||
             dato == '(') {
    preanalisis++;
    if (*preanalisis != '0' && *preanalisis != '1' && *preanalisis != '2' &&
        *preanalisis != '3' && *preanalisis != '4' && *preanalisis != '5' &&
        *preanalisis != '6' && *preanalisis != '7' && *preanalisis != '8' &&
        *preanalisis != '9' && *preanalisis != '(' && *preanalisis != '\00') {
      cout << "No coincide con la gramatica" << endl;
      exit;
    }
  }
  sem_cadena += dato;
}

float AnalizadorSintactico::term() { return fact(); }

float AnalizadorSintactico::Resto_expr(int num) {
  int s_resto, s_term, s_fact;

  switch (*preanalisis) {
    case '+':
      coincidir('+');
      s_term = term();
      s_resto = Resto_expr(s_term);
      num = num + s_resto;
      return num;
      break;
    case '-':
      coincidir('-');
      s_term = term();
      s_resto = Resto_expr(s_term);
      num = num - s_resto;
      return num;
      break;
    case '*':
      coincidir('*');
      s_fact = fact();
      num = num * s_fact;
      s_resto = Resto_expr(num);
      return s_resto;
      break;
    case '/':
      coincidir('/');
      s_fact = fact();
      num = num / s_fact;
      s_resto = Resto_expr(num);
      num = num + s_resto;
      return s_resto;
      break;
    case ')':
      coincidir(')');
      return num;
      break;
    default:
      return num;
      break;
  }
}

float AnalizadorSintactico::fact() {
  if (*preanalisis == '(') {
    coincidir('(');
    return expr();
  } else {
    return digito();
  }
}

float AnalizadorSintactico::digito() {
  switch (*preanalisis) {
    case '0':
      coincidir('0');
      return 0;
      break;
    case '1':
      coincidir('1');
      return 1;
      break;
    case '2':
      coincidir('2');
      return 2;
      break;
    case '3':
      coincidir('3');
      return 3;
      break;
    case '4':
      coincidir('4');
      return 4;
      break;
    case '5':
      coincidir('5');
      return 5;
      break;
    case '6':
      coincidir('6');
      return 6;
      break;
    case '7':
      coincidir('7');
      return 7;
      break;
    case '8':
      coincidir('8');
      return 8;
      break;
    case '9':
      coincidir('9');
      return 9;
      break;
    default:
      return 0;
      break;
  }
}

float AnalizadorSintactico::expr() {
  float s_term = term();
  float s_resto = Resto_expr(s_term);
  reglas = s_resto;
  return reglas;
}