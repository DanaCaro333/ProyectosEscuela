#include <iostream>
#include <string>

#include "AnalizadorSintactico.h"
using namespace std;

int main(int, char**) {
  string cadena;
  cout << "Ingrese una cadena: ";
  cin >> cadena;
  cout << "Resultado: ";
  AnalizadorSintactico prueba(cadena);
  cout
      << to_string(prueba.get_cadena())
      << endl;  // muestra el resultado de las reglas semánticas llevadas acabo.
}
