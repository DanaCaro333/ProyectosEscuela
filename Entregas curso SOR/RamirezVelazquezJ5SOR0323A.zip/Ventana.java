/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package act4;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Frame;
import java.awt.Panel;
import java.awt.TextArea;
import java.awt.TextField;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


/**
 *
 * @author danacaro
 */
public class Ventana extends Frame implements WindowListener, ActionListener{
    private TextArea area;
    private TextField campo;
    private Button  a,b,c;
    
    public Ventana(){
        super("EL TITULO DE LA VENTANA");
        
        setLayout(new BorderLayout());
        
        area = new TextArea();
        area.setEditable(false);
        campo = new TextField();
        campo.setEditable(true);
        
        
        
        PanelBotones pb = new PanelBotones();
        
        a.addActionListener(this);
        b.addActionListener(this);
        c.addActionListener(this);
        
        add("South",pb);
        
        add("Center",area);
        add("North",campo);
        addWindowListener(this); 
        
        setSize(400,400);
    }

    @Override
    public void actionPerformed(ActionEvent ae) { 
        
        String bot = ae.getActionCommand();
        
        if(bot.equalsIgnoreCase("Boton 1"))
            area.append(campo.getText() + " \n");
        if(bot.equalsIgnoreCase("Boton 2")){
            campo.setText("");
            area.setText("");
        }
        if(bot.equalsIgnoreCase("Boton 3"))
            setSize(600,600);
        
    }
    
    
    
    class PanelBotones extends Panel{
        public PanelBotones(){
            a = new Button("Boton 1");
            b = new Button("Boton 2");
            c = new Button("Boton 3");
            
            
            add(a);
            add(b);
            add(c);
        }
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Ventana v = new Ventana();
        v.setVisible(true);
    }

    @Override
    public void windowOpened(WindowEvent we) {
        System.out.println("VENTANA ABIERTA");
    }

    @Override
    public void windowClosing(WindowEvent we) {
        System.exit(0);
    }

    @Override
    public void windowClosed(WindowEvent we) {
    }

    @Override
    public void windowIconified(WindowEvent we) {
    }

    @Override
    public void windowDeiconified(WindowEvent we) {
    }

    @Override
    public void windowActivated(WindowEvent we) {
        System.out.println("VENTANA ACTIVA");
    }

    @Override
    public void windowDeactivated(WindowEvent we) {
    }
    
}
