/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package acti2;

/**
 *
 * @author danacaro
 */
public class Conversor {

    public static void main(String[] args) {
        
       byte  b = 0x57;
       short s = 0x5786;
       int e = 0x58756800;
       long l = 0x58756805875680L;
       
       metodo(b);
       metodo(s);
       metodo(e);
       metodo(l);
       
    }
    
private static void metodo(byte b){
    
    int aux = 0x80;
    
    for(int i=0; i<8; i++){
        
        if(i % 8 == 0)
            System.out.print("|");
        if((aux & b) == 0)
            System.out.print("0");
        else
            System.out.print("1");
        aux = aux >>> 1;
    }
    System.out.println("|");
      

}
private static void metodo(short s){
    int aux = 0x8000;
    
    for(int i=0; i<10; i++){
        
        if(i % 8 == 0)
            System.out.print("|");
        if((aux & s) == 0)
            System.out.print("0");
        else
            System.out.print("1");
        aux = aux >>> 1;
    }
    System.out.println("|");
        
}
private static void metodo(int e){
    int aux = 0x80000000;
    
    for(int i=0; i<32; i++){
        
        if(i % 8 == 0)
            System.out.print("|");
        if((aux & e) == 0)
            System.out.print("0");
        else
            System.out.print("1");
        aux = aux >>> 1;
    }
    System.out.println("|");
      

}
private static void metodo(long l){
    long aux = 0x8000000000000000L;
    
    for(int i=0; i<64; i++){
        
        if(i % 8 == 0)
            System.out.print("|");
        if((aux& l ) == 0)
            System.out.print("0");
        else
            System.out.print("1");
        aux = aux >>> 1;
    }
    System.out.println("|");
      
}
}


