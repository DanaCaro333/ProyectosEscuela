/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package act1;

import java.util.Scanner;

/**
 *
 * @author danacaro
 */
public class Encapsulamiento {
    
    public MiFecha mf;
    
    public Encapsulamiento(){
        mf = new MiFecha();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Encapsulamiento e = new Encapsulamiento();
        
        int salir = 0;
        Scanner s = new Scanner(System.in);
        
        while(salir != 4){
            System.out.println("DIA: "+ e.mf.dameDia() + " MES: " + e.mf.dameMes() + " ANIO: "+ e.mf.dameAnio());
            
            System.out.println("QUE DATO DESEAS CAMBIAR: ");
            System.out.println("1) DIA. ");
            System.out.println("2) MES. ");
            System.out.println("3) ANIO. ");
            System.out.println("4) SALIR. ");
            int opcion = s.nextInt();
            int dato = 0;
            boolean res;
            
            switch(opcion){
                case 1:
                    System.out.println("DAME EL NUEVO DIA: ");
                    dato = s.nextInt();
                    res = e.mf.fijaDia(dato);
                   
                    if(res)
                        System.out.println("FECHA MODIFICADA CORRECTAMENTE");
                    else
                        System.out.println("FECHA INCORRECTA - NO HAY MODIFICACIONES");
                    break;
                case 2:
                    System.out.println("DAME EL NUEVO MES: ");
                    dato = s.nextInt();
                    res = e.mf.fijaMes(dato);
                   
                    if(res)
                        System.out.println("FECHA MODIFICADA CORRECTAMENTE");
                    else
                        System.out.println("FECHA INCORRECTA - NO HAY MODIFICACIONES");
                    break;
                case 3:
                    System.out.println("DAME EL NUEVO ANIO: ");
                    dato = s.nextInt();
                    res = e.mf.fijaAnio(dato);
                   
                    if(res)
                        System.out.println("FECHA MODIFICADA CORRECTAMENTE");
                    else
                        System.out.println("FECHA INCORRECTA - NO HAY MODIFICACIONES");
                    break;
                case 4:
                    
                    break;
                
                default:
                    System.out.println("OPCION NO VALIDA");
                 
            }
        }
    }
    
    class MiFecha{
        
        private int dia, mes, anio;
        
        public MiFecha(){
            dia = 23;
            mes = 5;
            anio = 2001;
        }
        
        private boolean verificaFecha(int d, int m, int a){
            boolean bisiesto = false;
            
            if(a%4 == 0 & ((a%100 != 0) | (a%400 == 0)))
                bisiesto = true;
            
            if(d <1 | d > 31)
                return false;
            else
                if(m < 1 | m > 12)
                    return false;
                else
            if(d == 31 & (m == 2 |m == 4|m == 6|m == 9|m == 11))
                return false;
            else
                if(d == 30 & m == 2)                        
                    return false;
                else
                if(d == 29 & m == 2 & !bisiesto)
                    return false;

            return true;
        }
        
        public int dameDia(){
            return dia;
        }
        public int dameMes(){
            return mes;
        }
        public int dameAnio(){
            return anio;
        }
        
        public boolean fijaDia(int d){
            if(verificaFecha(d, mes, anio)){
               dia = d; 
               return true;
            } 
            return false;
        }
        public boolean fijaMes(int m){
            if(verificaFecha(dia, m, anio)){
                mes = m;
                return true;
            }
            return false;
        }
        public boolean fijaAnio(int a){
            if(verificaFecha(dia, mes, a)){
                anio = a;
                return true;
             }
            return false;
        }
    }
}
