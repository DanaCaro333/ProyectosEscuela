
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author danacaro
 */
public class ClaseAdministradora {
    
    private int contador;
    private Hashtable<Integer,Materia> datos;
    
    public ClaseAdministradora(){
        contador = 1;
        datos = new Hashtable<Integer,Materia>();
    }
    
    class Materia{
        public String nrc, nombre;
        
        public Materia(String clave, String name){
            nrc = clave;
            nombre = name;
        }
    }
    
    public int alta(String clave, String name){
        Materia m = new Materia(clave, name);
        datos.put(contador, m);
        return contador++;
    }
    
    public Materia consulta(int id){
        Materia aux = datos.get(id);       
        return aux;
    }
    
    public void baja(int id){ 
        datos.remove(id);
    }
    
    public void imprimir(){
        System.out.println();
        Enumeration<Integer> e = datos.keys();
        Enumeration<Materia> m = datos.elements();
        
        System.out.println("ID SEC |  NRC  |      MATERIA                 |");
        while(e.hasMoreElements()){
            Materia aux = m.nextElement();
            
            System.out.println("  " +e.nextElement() + "    | " + aux.nrc + " | " + aux.nombre);
        }
    }
    
    
    public static void main(String[] args){
        ClaseAdministradora ca = new ClaseAdministradora();
        
        int salir = 0;
        Scanner s = new Scanner(System.in);
        
        ca.alta("17029", "SISTEMAS OPERATIVOS");
        ca.alta("17030", "SEMINARIO DE SISTEMAS OPERATIVOS");
        ca.alta("17033", "SISTEMAS OPERATIVOS DE RED");
        ca.alta("17034", "SEMINARIO DE SISTEMAS OPERATIVOS DE RED");
        
        while(salir != 5){
            System.out.println();
            System.out.println("        MENU        ");
            System.out.println("1.- ALTA MATERIA");
            System.out.println("2.- CONSULTA MATERIA");
            System.out.println("3.- BAJA MATERIA");
            System.out.println("4.- IMPRIMIR");
            System.out.println("5.- SALIR");
            
            
            int opc = s.nextInt();
            
            switch(opc){
                case 1:
                    String nrc, nombre;
                    System.out.println("DAME EL NRC: ");
                    nrc = s.next();
                    System.out.println("DAME EL NOMBRE: ");
                    nombre = s.next();
                    
                    int id = ca.alta(nrc, nombre);
                    
                    ca.imprimir();
                    System.out.println("Se registro con el id: "+id);
                    break;
                case 2:
                    System.out.println("DAME LA CLAVE: ");
                    int id2 = s.nextInt();
                    
                    Materia aux = ca.consulta(id2);
                    try {
                        System.out.println("NRC MATERIA: "+aux.nrc+" | NOMBRE MATERIA: "+aux.nombre);  
                    }catch(NullPointerException ex){
                        System.out.println("Ese ID no existe...");
                    }
                    break;
                case 3:
                    System.out.println("DAME LA CLAVE: ");
                    int id3 = s.nextInt();
                    
                    ca.baja(id3);
                    break;
                case 4:
                   ca.imprimir();
                    break;
                case 5:
                    System.out.println("ADIOS :)");
                    salir = 5;
                    break;
                default:
                    System.out.println("OPCION NO VALIDA");
                
            }
        }
        
    }
}
