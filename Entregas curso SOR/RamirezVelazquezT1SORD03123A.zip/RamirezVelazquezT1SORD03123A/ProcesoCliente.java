
import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Choice;
import java.awt.Frame;
import java.awt.Panel;
import java.awt.TextArea;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.lang.System.Logger;
import java.lang.System.Logger.Level;
import java.net.Socket;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author danacaro 
 */
public class ProcesoCliente extends Frame implements WindowListener, ActionListener {
    TextArea respuesta = new TextArea();
    TextArea instrucciones = new TextArea();
    TextField num = new TextField("Numero: ");
    TextField numero = new TextField();
    Choice seleccion = new Choice();
    Button boton = new Button("BUSCAR");
    Socket socket = null;
    Panel panel = new Panel();
    ObjectOutputStream objOut = null;
    ObjectInputStream objIn = null;
        
    public ProcesoCliente(){
        super("CLIENTE");
        setLayout(new BorderLayout());
        respuesta = new TextArea();
        respuesta.setEditable(false);
        String inst = "Servicios para solicitar (\"n\" es el numero ingresado): \n";
        inst += "   *Regresa el numero n en hexadecimal\n";
        inst += "   *Regresa el numero n en binario\n";
        inst += "   *Regresa el numero n en en octal\n";
        instrucciones = new TextArea(inst);
        instrucciones.setEditable(false);
        num.setEditable(false);
        numero.setColumns(3);
        
        
        seleccion.add("hexadecimal");
        seleccion.add("binario");
        seleccion.add("octal");
        
        panel.add(num);
        panel.add(numero);
        panel.add(seleccion);
        panel.add(boton);
        
        add("North", panel);
        add("South", instrucciones);
        add("Center", respuesta);
        
        boton.addActionListener(this);
        setSize(500,500);
        addWindowListener(this);
        
    }
    public static void main(String[] args) throws IOException{
        ProcesoCliente cliente = new ProcesoCliente();
        cliente.setVisible(true);
    }

    @Override
    public void windowOpened(WindowEvent we) {
    }

    @Override
    public void windowClosing(WindowEvent we) {
        System.exit(0);
    }

    @Override
    public void windowClosed(WindowEvent we) {
    }

    @Override
    public void windowIconified(WindowEvent we) {
    }

    @Override
    public void windowDeiconified(WindowEvent we) {
    }

    @Override
    public void windowActivated(WindowEvent we) {
    }

    @Override
    public void windowDeactivated(WindowEvent we) {
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String comando = e.getActionCommand();
        
        if(comando.equalsIgnoreCase("BUSCAR")){
            try {
                socket = new Socket("127.0.0.1", 4545);
                objOut = new ObjectOutputStream(socket.getOutputStream());
                objIn = new ObjectInputStream(socket.getInputStream());
                
                String numeroRes = numero.getText();
                numeroRes += "|" + seleccion.getSelectedIndex();
                objOut.writeObject(numeroRes);
                
                String respuestaSer = (String)objIn.readObject();
                respuesta.append(respuestaSer + "\n\n");
            } catch(IOException ex){
                System.out.println(ex);
            } catch(ClassNotFoundException ex){
                System.out.println(ex);
            }
        }
        else
            System.out.println("XDDD");
    }
    
}
