
import java.awt.BorderLayout;
import java.awt.Frame;
import java.awt.TextArea;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Hashtable;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author danacaro
 */
public class ProcesoServidor extends Frame implements WindowListener, ActionListener {

    private static String hexadecimal(Integer n) {
        String hexadecimal = "";
        String caracteresHexadecimales = "0123456789abcdef";
        while (n > 0) {
            int residuo = n % 16;
            hexadecimal = caracteresHexadecimales.charAt(residuo) + hexadecimal; 
            n /= 16;
        }
        return hexadecimal;
    }

    private static String binario(Integer n) {
	if (n <= 0) {
		return "0";
	}
	StringBuilder binario = new StringBuilder();
	while (n > 0) {
		short residuo = (short) (n % 2);
		n = n / 2;
		binario.insert(0, String.valueOf(residuo));
	}
	return binario.toString();
    }

    private static String octal(Integer n) {
         String octal = "";
        String caracteresOctales = "01234567";
        while (n > 0) {
            int residuo = n % 8;

            octal = (caracteresOctales.charAt(residuo) + octal);
            n /= 8;
        }
        return octal;
    }
    
    
    
    TextArea respuestaFib = new TextArea();
    TextArea info = new TextArea();
    static Hashtable<Integer, String> tablaServicios = new Hashtable<Integer, String>();
    public ProcesoServidor(){
        super("SERVIDOR");
        tablaServicios.put(0,"Hexadecimal");
        tablaServicios.put(1,"Binario");
        tablaServicios.put(2,"Octal");
        
        setLayout(new BorderLayout());
        respuestaFib.setEditable(false);
        
        String cad = "Servidor que ofrece tres tipos de servicios:\n";
        cad += "\n* Hexadecimal: convierte los numero a hexadecimal";
        cad += "\n* Binario: convierte los numero a binario";
        cad += "\n* Octal: convierte los numero a octal";
        info = new TextArea(cad);
        info.setEditable(false);
        
        add(respuestaFib, "North");
        add(info, "Center");
        setSize(400,400);
        addWindowListener(this);

    }
    
    public static void main(String[] args)throws IOException{
        ProcesoServidor servidor = new ProcesoServidor();
        servidor.setVisible(true);
        ObjectInputStream objIn = null;
        ObjectOutputStream objOut = null;
        Socket socket = null;
        ServerSocket sSocket = new ServerSocket(4545);
        
        while(true){
            try{
                socket = sSocket.accept();
                
                servidor.respuestaFib.append("Conexion con el cliente de la direccion IP: " + socket.getInetAddress() + "\n");
                objIn = new ObjectInputStream(socket.getInputStream());
                objOut = new ObjectOutputStream(socket.getOutputStream());
                
                String respuesta = (String)objIn.readObject();
                String[] servicio = respuesta.split("\\|");
                Integer n = Integer.parseInt(servicio[0]);
                int servicioSol = Integer.parseInt(servicio[1]);
                String response = "";
                String num = new String();
                
                servidor.respuestaFib.append("solicitud recibida" + "\n");
                servidor.respuestaFib.append("El servicio solicitado es: " + tablaServicios.get(servicioSol).toUpperCase()+"\n");
                switch(servicioSol){
                    case 0:
                        num = hexadecimal(n);
                        response = "El numero " + n.toString() + "en Hexadecimal eses: "+ num;
                        break;
                    case 1:
                        num = binario(n);
                        response = "El numero " + n.toString() + "en Binario es: "+ num;
                        break;
                    case 2:
                        num = octal(n);
                        response = "El numero " + n.toString() + "en Octal es: "+ num;
                        break;
                    default:
                        response = "La solicitud no aloja resultado";
                }
                objOut.writeObject(response);
                servidor.respuestaFib.append("Respuesta enviada" + "\n\n");
                System.out.println("Mensaje enviado");
            } catch(Exception ex){
                ex.printStackTrace();
            }
        }
        
    }

    @Override
    public void windowOpened(WindowEvent we) {
    }

    @Override
    public void windowClosing(WindowEvent we) {
        System.exit(0);
    }

    @Override
    public void windowClosed(WindowEvent we) {
    }

    @Override
    public void windowIconified(WindowEvent we) {
    }

    @Override
    public void windowDeiconified(WindowEvent we) {
    }

    @Override
    public void windowActivated(WindowEvent we) {
    }

    @Override
    public void windowDeactivated(WindowEvent we) {
    }

    @Override
    public void actionPerformed(ActionEvent ae) {
    }
    
}
