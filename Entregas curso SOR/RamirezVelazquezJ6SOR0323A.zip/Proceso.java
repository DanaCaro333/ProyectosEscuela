/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author danacaro
 */
public class Proceso {
    public static void main(String[] args){
        Proceso p = new Proceso();
        int va = 9;
        
        int[] ar = new int[1];
        ar[0] = va;
        
        p.valor(va,va);
        System.out.println("VALOR VA EN MAIN: "+va);
        
        p.referencia(ar,ar);
        System.out.println("VALOR AR EN MAIN: "+ar[0]);
        
    }
    
    private void referencia(int[] ar1, int[] ar2){
        ar1[0] = ar1[0]*ar1[0];
        System.out.println("VALOR AR1 = "+ar1[0]);
        
        ar2[0] = ar2[0] - ar1[0];
        System.out.println("VALOR AR2 = "+ar2[0]);
    }
    
    private void valor(int va1, int va2){
        va1 = va1*va2;
        System.out.println("VALOR VA1 = "+va1);
        
        va2 = va2 - va1;
        System.out.println("VALOR VA2 = "+va2);
    }
}
