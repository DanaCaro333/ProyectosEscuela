
import java.awt.Button;
import java.awt.Frame;
import java.awt.Label;
import java.awt.Panel;
import java.awt.TextArea;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.logging.Level;
import java.util.logging.Logger;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author danacaro
 */
public class Chat extends Frame implements WindowListener, ActionListener {
    private TextArea area;
    private TextField ipT, msjT;
    private Button boton;
    private DatagramSocket socketRecepcion, socketEmision;
    private Receptor ar;
    
    public Chat(){
        
        super("Chat Version Premium");
        
        area = new TextArea();
        area.setEditable(false);
        boton = new Button("Enviar");
        
        PanelSup p1 = new PanelSup();
        
        add("North", p1);
        add("Center", area);
        add("South", boton);
        
        setSize(500,500);
        
        ar = new Receptor();
        ar.start();
        
        addWindowListener(this);
        boton.addActionListener(this);

        
    }
    
    class PanelSup extends Panel{
        PanelSup(){
            ipT = new TextField(15);
            add(new Label("IP"));
            add(ipT);
            
            msjT = new TextField(15);
            add(new Label("Mensaje"));
            add(msjT);
        }
        
    }
    
    class Receptor extends Thread{
        public void run(){
            int puertoEntrada = 3121;
            try{
                socketRecepcion = new DatagramSocket(puertoEntrada);
                
                byte[] buffer = new byte[1024];
                
                DatagramPacket dp;
                dp = new DatagramPacket(buffer, buffer.length);
                
                System.out.println("ENTRO AL HILO");
                while(true){
                    try{
                        socketRecepcion.receive(dp);
                        
                        area.append("IP emisora: "+dp.getAddress().getHostAddress()+":");
			area.append(new String(buffer,0,dp.getLength())+"\n");

                        
                    }catch (IOException ex) {
                        Logger.getLogger(Chat.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
                
            }catch(SocketException e){
                
            } 

            
        }
    }
    
    @Override
    public void windowOpened(WindowEvent we) {
    }

    @Override
    public void windowClosing(WindowEvent we) {
        System.exit(0);
    }

    @Override
    public void windowClosed(WindowEvent we) {
    }

    @Override
    public void windowIconified(WindowEvent we) {
    }

    @Override
    public void windowDeiconified(WindowEvent we) {
    }

    @Override
    public void windowActivated(WindowEvent we) {
    }

    @Override
    public void windowDeactivated(WindowEvent we) {
    }

    @Override
    public void actionPerformed(ActionEvent ae) {
        
        String ip = ipT.getText();
        String mensaje = msjT.getText();
        
        byte[] buffer;
        buffer = mensaje.getBytes();
        
        
        try {
            socketEmision = new DatagramSocket();
            
            DatagramPacket dp;
            try {
                
                dp = new DatagramPacket(buffer, buffer.length, InetAddress.getByName(ip),4321);
                
                try {
                    socketEmision.send(dp);
                    socketEmision.close();
                } catch (IOException ex) {
                    Logger.getLogger(Chat.class.getName()).log(Level.SEVERE, null, ex);
                }
                
            } catch (UnknownHostException ex) {
                Logger.getLogger(Chat.class.getName()).log(Level.SEVERE, null, ex);
            }
            
        } catch (SocketException ex) {
            Logger.getLogger(Chat.class.getName()).log(Level.SEVERE, null, ex);
        }
       
    }
    
    public static void main(String[] args){
        Chat m = new Chat();
        m.setVisible(true);
        
        
    }
}
//192.168.1.179