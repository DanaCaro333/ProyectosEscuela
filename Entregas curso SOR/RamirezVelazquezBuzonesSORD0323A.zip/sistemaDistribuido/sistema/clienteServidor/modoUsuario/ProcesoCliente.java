package sistemaDistribuido.sistema.clienteServidor.modoUsuario;

import sistemaDistribuido.sistema.clienteServidor.modoMonitor.Nucleo;
import sistemaDistribuido.sistema.clienteServidor.modoUsuario.Proceso;
import sistemaDistribuido.util.Escribano;

/**
 * 
 */
public class ProcesoCliente extends Proceso{

	/**
	 * 
	 */
        private short codop;
        private String data;
	public ProcesoCliente(Escribano esc){
		super(esc);
		start();
	}

	private static byte[] empaqueta(short s){
            byte[] OrdenS = new byte[2];

            for(int i=0; i < 2; i++){
                OrdenS[i] = (byte) s;
                s = (short) (s>>>8);
            }

            return OrdenS;
        }
        
        private static byte[] empaqueta(int e){
            byte[] OrdenE = new byte[4];

            for(int i=0; i < 4; i++){
                OrdenE[i] = (byte) e;
                e = e>>>8;
            }

            return OrdenE;
        }
        
        private static int reordenE(byte[] orden){
        
        int valor = 0;
        int aux;
        
        for(int i = 3; i >= 0; i--){
            valor = valor<<8;
            aux = orden[i];
            aux = aux&0x0000FF;
            valor = valor|aux;
            
        }
  
        return valor;
        
    }
        
	public void run(){
		imprimeln("Proceso cliente en ejecucion.");
		imprimeln("Esperando datos para continuar.");
		Nucleo.suspenderProceso();
                
                imprimeln("CREANDO EL PAQUETE SOLICITUD");
		byte[] solCliente=new byte[1024];
		byte[] respCliente=new byte[1024];
		byte[] arregloB = empaqueta(codop);
               
                imprimeln("EMPAQUETANDO EL CODOP");
                System.arraycopy(arregloB,0,solCliente,8,arregloB.length);
                
                int tam = data.length();
                byte[] arregloB2 = empaqueta(tam);
                System.arraycopy(arregloB2,0,solCliente,10,arregloB2.length);
                byte[] cad = data.getBytes();
                System.arraycopy(cad,0,solCliente,14,cad.length);
                imprimeln("INVOCANDO A SEND PARA EL ENVIO DE SOLICITUD");
		Nucleo.send(248,solCliente);
                imprimeln("INVOCANDO A RECIEVE PARA EL ENVIO DE SOLICITUD");
                Nucleo.receive(dameID(), respCliente);
                
                
                String resp;
                int tamResp;
                byte[] r1 = new byte[4];
                System.arraycopy(respCliente,8,r1,0,4);
                tamResp = reordenE(r1);
                
                resp = new String(respCliente, 12, tamResp);
                
                imprimeln("LA RESPUESTA DEL SERVIDOR ES: "+ resp);
                
	}

    public void roku(int selectedIndex, String text) {
        codop = (short) selectedIndex;
        data = text;
    }
}
