package sistemaDistribuido.sistema.clienteServidor.modoUsuario;

import sistemaDistribuido.sistema.clienteServidor.modoMonitor.Nucleo;
import sistemaDistribuido.sistema.clienteServidor.modoUsuario.Proceso;
import sistemaDistribuido.util.Escribano;
import sistemaDistribuido.util.Pausador;

/**
 * 
 */
public class ProcesoServidor extends Proceso{

	/**
	 * 
	 */
	public ProcesoServidor(Escribano esc){
		super(esc);
		start();
	}
        
        
        private static short reordenS(byte[] orden){
        
        short valor = 0;
        short aux;
        
        for(int i = 1; i >= 0; i--){
            valor = (short) (valor<<8);
            aux = orden[i];
            aux = (short) (aux&0x00FF);
            valor = (short) (valor|aux);
            
        }
  
        return valor;
        
    }
         private static int reordenE(byte[] orden){
        
        int valor = 0;
        int aux;
        
        for(int i = 3; i >= 0; i--){
            valor = valor<<8;
            aux = orden[i];
            aux = aux&0x0000FF;
            valor = valor|aux;
            
        }
  
        return valor;
        
    }
         private static byte[] empaqueta(int e){
            byte[] OrdenE = new byte[4];

            for(int i=0; i < 4; i++){
                OrdenE[i] = (byte) e;
                e = e>>>8;
            }

            return OrdenE;
        }

	/**
	 * 
	 */
	public void run(){
		imprimeln("Proceso servidor en ejecucion.");
		byte[] solServidor=new byte[1024];
		byte[] respServidor;
		byte dato;
                
                Nucleo.nucleo.abreBuzon(dameID());
                
		while(continuar()){
                        imprimeln("INVOCANDO A RECIEVE EN ESPERA DE SOLICITUDES");
			Nucleo.receive(dameID(),solServidor);
                        
                        imprimeln("SE HA RECIBIDO UNA SOLICITUD YUJU");
                        
                        short codop;
                        String cad;
                        imprimeln("SACANDO EL CODOP");
                        byte[] ar = new byte[2];
                        System.arraycopy(solServidor,8,ar,0,2);
                        codop = reordenS(ar);
                        
                        imprimeln("SACANDO LOS DATOS RELATIVOS DE LA OPERACION");
                        byte[] ar2 = new byte[4];
                        System.arraycopy(solServidor,10,ar2,0,4);
                        int tam = reordenE(ar2);
                        cad = new String(solServidor,14,tam);
                        
                        imprimeln("EL CODIGO DE OPERACION ES " + codop + "LOS DATOS RELATIVOS SON: " + cad);
                        
                        imprimeln("REALIZANDO LA OPERACION");
                        String respuesta;
                        
                        switch(codop){
                            case 0:
                                respuesta = "EL ARCHIVO DEL NOMBRE "+cad+"HA SIDO CREADO DE MANERA CORRECTA";
                                imprimeln(respuesta);
                                break;
                            case 1:
                                respuesta = "EL ARCHIVO DEL NOMBRE "+cad+"HA SIDO ELIMINADO DE MANERA CORRECTA";
                                imprimeln(respuesta);
                                break;
                            case 2:
                                respuesta = "EL ARCHIVO DEL NOMBRE "+cad+"HA SIDO LEIDO DE MANERA CORRECTA";
                                imprimeln(respuesta);
                                break;
                            case 3:
                                respuesta = "EL ARCHIVO DEL NOMBRE "+cad+"HA SIDO ESCRITO DE MANERA CORRECTA";
                                imprimeln(respuesta);
                                break;
                            default:
                                respuesta = "OPERACION ERRONEA, ESE CODO NO EXISTE";
                                imprimeln(respuesta);
                                break;
                        }
                        imprimeln("ELABORANDO LA RESPUESTA");
			respServidor=new byte[1024];
                        byte[] r1 = empaqueta(respuesta.length());
                        System.arraycopy(r1,0,respServidor,8,4);
                        byte[] c1 = respuesta.getBytes();
                        System.arraycopy(c1,0,respServidor,12,respuesta.length());
                        
			Pausador.pausa(10000);  
			imprimeln("enviando respuesta");
                        byte[] num = new byte[4];
                        System.arraycopy(solServidor, 0, num, 0, 4);
                        
                        int origen = reordenE(num);
                        
			imprimeln("ENVIANDO RESPUESTA AL ID NUM: "+origen);
			Nucleo.send(origen,respServidor);
                        imprimeln("...Listo");
		}
	}
}
