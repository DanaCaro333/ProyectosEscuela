/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package act3;


public class CadenaBytes {


    public static void main(String[] args) {        
        byte[] arre;
        
        String cadena = "QUE PLAN EL SABADRINK";
        
        arre = new byte[cadena.length()+1];
        
        byte[] arre2 = cadena.getBytes();
        
        arre[0]= (byte)cadena.length();
        
        System.arraycopy(arre2, 0, arre, 1, arre[0]);
        
        for(int i = 0; i < arre.length; i++){
            System.out.print(arre[i] + " ");
        }
        System.out.println();
        
        metodo(arre);
    }
    
    private static void metodo(byte[] arre){
        String cadena = new String(arre, 1, arre[0]);
        
        System.out.println("LA CADENA REARMADA SE VE ASI: " + cadena);
    }
    
}
