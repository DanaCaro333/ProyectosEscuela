package sistemaDistribuido.sistema.clienteServidor.modoMonitor;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Hashtable;
import java.util.logging.Level;
import java.util.logging.Logger;
import sistemaDistribuido.sistema.clienteServidor.modoMonitor.MicroNucleoBase;
import sistemaDistribuido.sistema.clienteServidor.modoUsuario.Proceso;

/**
 * 
 */
public final class MicroNucleo extends MicroNucleoBase{
	private static MicroNucleo nucleo=new MicroNucleo();
        
        Hashtable<Integer, ParMaquinaProceso> te = new Hashtable<Integer, ParMaquinaProceso>();
        Hashtable<Integer, byte[]> tablaRecepcion = new Hashtable<Integer, byte[]>();

	/**
	 * 
	 */
	private MicroNucleo(){
	}

	/**
	 * 
	 */
	public final static MicroNucleo obtenerMicroNucleo(){
		return nucleo;
	}

	/*---Metodos para probar el paso de mensajes entre los procesos cliente y servidor en ausencia de datagramas.
    Esta es una forma incorrecta de programacion "por uso de variables globales" (en este caso atributos de clase)
    ya que, para empezar, no se usan ambos parametros en los metodos y fallaria si dos procesos invocaran
    simultaneamente a receiveFalso() al reescriir el atributo mensaje---*/
	byte[] mensaje;

	public void sendFalso(int dest,byte[] message){
		System.arraycopy(message,0,mensaje,0,message.length);
		notificarHilos();  //Reanuda la ejecucion del proceso que haya invocado a receiveFalso()
	}

	public void receiveFalso(int addr,byte[] message){
		mensaje=message;
		suspenderProceso();
	}
	/*---------------------------------------------------------*/

	/**
	 * 
	 */
	protected boolean iniciarModulos(){
		return true;
	}

	/**
	 * 
	 */
        
        private static byte[] empaqueta(int e){
            byte[] OrdenE = new byte[4];

            for(int i=0; i < 4; i++){
                OrdenE[i] = (byte) e;
                e = e>>>8;
            }

            return OrdenE;
        }
        
	protected void sendVerdadero(int dest,byte[] message){
		//sendFalso(dest,message);
		imprimeln("El proceso invocante es el "+super.dameIdProceso());
                
                imprimeln("BUSCANDO LOS DATOS DEL DESTINO");
                ParMaquinaProceso pmp = te.get(dest);
		
                if(pmp == null)
                    pmp=dameDestinatarioDesdeInterfaz();
                
		imprimeln("Enviando mensaje a IP="+pmp.dameIP()+" ID="+pmp.dameID());
                int origen = super.dameIdProceso();
                int destino = pmp.dameID();
                
                imprimeln("EMPAQUETANDO OTIGEN");
                byte[] arr = empaqueta(origen);
                System.arraycopy(arr, 0,message, 0, 4);
                
                imprimeln("EMPAQUETANDO DESTINO");
                arr = empaqueta(destino);
                System.arraycopy(arr, 0,message, 4, 4);
                
            try {
                imprimeln("CREANDO EL PAQUETE");
                DatagramPacket dp = new DatagramPacket(message,message.length,InetAddress.getByName(pmp.dameIP()),damePuertoRecepcion());
                
                imprimeln("OBTENIENDO EL SOCKET");
                DatagramSocket socketEmision = dameSocketEmision();
                socketEmision.send(dp);
            } catch (UnknownHostException ex) {
                Logger.getLogger(MicroNucleo.class.getName()).log(Level.SEVERE, null, ex);
            } catch (IOException ex) {
                Logger.getLogger(MicroNucleo.class.getName()).log(Level.SEVERE, null, ex);
            }
                
		//suspenderProceso();   //esta invocacion depende de si se requiere bloquear al hilo de control invocador
		
	}

	/**
	 * 
	 */
	protected void receiveVerdadero(int addr,byte[] message){
		//receiveFalso(addr,message);
		//el siguiente aplica para la pr�ctica #2
                tablaRecepcion.put(addr, message);
		suspenderProceso();
	}

	/**
	 * Para el(la) encargad@ de direccionamiento por servidor de nombres en pr�ctica 5  
	 */
	protected void sendVerdadero(String dest,byte[] message){
	}

	/**
	 * Para el(la) encargad@ de primitivas sin bloqueo en pr�ctica 5
	 */
	protected void sendNBVerdadero(int dest,byte[] message){
	}

	/**
	 * Para el(la) encargad@ de primitivas sin bloqueo en pr�ctica 5
	 */
	protected void receiveNBVerdadero(int addr,byte[] message){
	}

	/**
	 * 
	 */
        
        private static int reordenE(byte[] orden){
        
        int valor = 0;
        int aux;
        
        for(int i = 3; i >= 0; i--){
            valor = valor<<8;
            aux = orden[i];
            aux = aux&0x0000FF;
            valor = valor|aux;
            
        }
  
        return valor;
        
    }
        class Datos implements ParMaquinaProceso{
            
            private int id;
            private String ip;
            
            public Datos(int i, String p){
                id = i;
                ip = p;
            }

            @Override
            public String dameIP() {

                return ip;
            }

            @Override
            public int dameID() {

                return id;
            }
             
        }
         
	public void run(){
            
            imprimeln("PREPARANDO PARA RECIBIR MENSAJES DE LA RED");
            byte[] buffer = new byte[1024];
            DatagramPacket dp = new DatagramPacket(buffer, buffer.length);
            DatagramSocket recepcion = dameSocketRecepcion();

            while(seguirEsperandoDatagramas()){
                imprimeln("INVOCANDO A RECIEVE");
                
                try {
                    recepcion.receive(dp);
                    imprimeln("SE RECIBIO EL PAQUETE");
                    
                    int origen, destino;
                    String ip;
                    
                    imprimeln("SACANDO ORIGEN");
                    byte[] ae = new byte[4];
                    System.arraycopy(buffer, 0, ae, 0, 4);
                    origen = reordenE(ae);
                    
                    imprimeln("SACANDO DESTINO");
                    System.arraycopy(buffer, 4, ae, 0, 4);
                    destino = reordenE(ae);
                    
                    imprimeln("SACANDO IP ORIGEN");
                    ip = dp.getAddress().getHostAddress();
                    
                    imprimeln("EL ORIGEN ES: "+origen);
                    imprimeln("EL DESTINO ES: "+destino);
                    imprimeln("EL IP ES: "+ip);
                    
                    Proceso p = dameProcesoLocal(destino);
                    
                    if(buffer[1023] == -100){
                        imprimeln("RECIBI UN AU");
                        imprimeln("DESPERTAREMOS AL ORIGEN");
                        
                        Proceso p3 = dameProcesoLocal(origen);
                        
                        reanudarProceso(p3);
                    }
                    else{
                        if(p!=null){

                            imprimeln("VIENDO SI DESTINO ESPERA RECIBIR");
                            byte[] arreglo = tablaRecepcion.get(destino);

                            if(arreglo != null){
                                tablaRecepcion.remove(destino);

                                imprimeln("GUARDANDO DATOS DEL ORIGEN");


                                Datos d = new Datos(origen, ip);
                                te.put(origen, d);

                                imprimeln("COPIANDO DATOS AL DESTINO");
                                System.arraycopy(buffer, 0, arreglo, 0, arreglo.length);

                                reanudarProceso(p);

                            }else{
                                //AQUI PROGRAMAREMOS EL TA
                            }
                        }else{
                            buffer[1023] = -100;

                            DatagramPacket dp2;
                            dp2 = new DatagramPacket(buffer,buffer.length, InetAddress.getByName(ip), damePuertoRecepcion());

                            DatagramSocket socketEmision = dameSocketEmision();

                            socketEmision.send(dp2);
                        }

                    }    
                } catch (IOException ex) {
                    Logger.getLogger(MicroNucleo.class.getName()).log(Level.SEVERE, null, ex);
                }

            }
	}
}
