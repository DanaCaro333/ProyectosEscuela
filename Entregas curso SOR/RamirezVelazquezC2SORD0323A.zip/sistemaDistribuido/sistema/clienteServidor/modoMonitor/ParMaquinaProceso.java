package sistemaDistribuido.sistema.clienteServidor.modoMonitor;

public interface ParMaquinaProceso{

	public String dameIP();
	public int dameID();
}
