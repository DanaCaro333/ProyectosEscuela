
import java.util.Random;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author danacaro
 */
public class Arreglos {
    
    public static void main(String[] args){
        char[] arreglo;
        Random r = new Random();
        
        int tam = r.nextInt(100);
        arreglo = new char[tam];
        
        String abc = "ABCDEFGHIJLMNOPQRSTUVWXYZ";
        
        for(int i = 0; i < tam; i++){
            arreglo[i] = abc.charAt(r.nextInt(abc.length()));
        }
        
        System.out.println(arreglo);
        acomodo(arreglo);
        System.out.println(arreglo);
    }
    
    private static void acomodo(char[] array){
        String palabra = "MEDIOMETRO";
        
        int lp = palabra.length();
        int res = array.length;
        int indice = 0;
        
        while(res-lp >= 0){
            for(int i = 0; i < lp; i++){
                array[indice] = palabra.charAt(i);
                indice++;
            }
            
            res = res - lp;
        }
    }
}
