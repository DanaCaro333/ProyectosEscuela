/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package act4;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Frame;
import java.awt.Panel;
import java.awt.TextArea;
import java.awt.TextField;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

/**
 *
 * @author danacaro
 */
public class Ventana extends Frame implements WindowListener{
    private TextArea area;
    private TextField campo;
    private Button  a,b,c;
    
    public Ventana(){
        super("EL TITULO DE LA VENTANA");
        
        setLayout(new BorderLayout());
        
        area = new TextArea();
        area.setEditable(false);
        campo = new TextField();
        campo.setEditable(true);
        
        add("Center",area);
        add("North",campo);
        
        PanelBotones pb = new PanelBotones();
        
        add("South",pb);
        
        
        addWindowListener(this); //*Deja de funcionar el TextField cuando le activo el WindowListener
        
        setSize(400,400);
    }
    
    class PanelBotones extends Panel{
        public PanelBotones(){
            a = new Button("Boton 1");
            b = new Button("Boton 2");
            c = new Button("Boton 3");
            
            add(a);
            add(b);
            add(c);
        }
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Ventana v = new Ventana();
        v.setVisible(true);
    }

    @Override
    public void windowOpened(WindowEvent we) {
        System.out.println("VENTANA ABIERTA");
    }

    @Override
    public void windowClosing(WindowEvent we) {
        System.exit(0);
    }

    @Override
    public void windowClosed(WindowEvent we) {
    }

    @Override
    public void windowIconified(WindowEvent we) {
    }

    @Override
    public void windowDeiconified(WindowEvent we) {
    }

    @Override
    public void windowActivated(WindowEvent we) {
        System.out.println("VENTANA ACTIVA");
    }

    @Override
    public void windowDeactivated(WindowEvent we) {
    }
    
}
