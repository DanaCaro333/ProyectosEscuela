/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author danacaro
 */
public class Parametros {
    
    public static void main(String[] args){
        short s = 5247; //0x090A;
        int e = 56458; //0x0B0C0D0E;
        long l = 5645567556458L; //0x0B0C0D0E0B0C0D0EL;
        
        byte[] OrdenS;
        byte[] OrdenE;
        byte[] OrdenL;
        
        OrdenS = orden(s);
        OrdenE = orden(e);        
        OrdenL = orden(l);        
        
        
        for(int i = 0; i<OrdenS.length;i++){
            System.out.print(OrdenS[i] + " ");
        }
        
        System.out.println();
        
        for(int i = 0; i<OrdenE.length;i++){
            System.out.print(OrdenE[i] + " ");
        }
        
        System.out.println();
        
        for(int i = 0; i<OrdenL.length;i++){
            System.out.print(OrdenL[i] + " ");
        }
        
        System.out.println();
        
        short reOrdenS = reordenS(OrdenS);
        System.out.println("EL NUMERO SHORT REARMADO = " + reOrdenS);
        
        int reOrdenE = reordenE(OrdenE);     
        System.out.println("EL NUMERO ENTERO REARMADO = " + reOrdenE);
        
        long reOrdenL = reordenL(OrdenL);  
        System.out.println("EL NUMERO LAEGO REARMADO = " + reOrdenL);
        
    }
    
    private static short reordenS(byte[] orden){
        
        short valor = 0;
        short aux;
        
        for(int i = 1; i >= 0; i--){
            valor = (short) (valor<<8);
            aux = orden[i];
            aux = (short) (aux&0x00FF);
            valor = (short) (valor|aux);
            
        }
  
        return valor;
        
    }
    
    private static int reordenE(byte[] orden){
        
        int valor = 0;
        int aux;
        
        for(int i = 3; i >= 0; i--){
            valor = valor<<8;
            aux = orden[i];
            aux = aux&0x0000FF;
            valor = valor|aux;
            
        }
  
        return valor;
        
    }
    
    private static long reordenL(byte[] orden){
        
        long valor = 0;
        long aux;
        
        for(int i = 7; i >= 0; i--){
            valor = valor<<8;
            aux = orden[i];
            aux = aux&0x0000000000FF;
            valor = valor|aux;
            
        }
  
        return valor;
        
    }
    
    private static byte[] orden(short s){
        byte[] OrdenS = new byte[2];
        
        for(int i=0; i < 2; i++){
            OrdenS[i] = (byte) s;
            s = (short) (s>>>8);
        }
        
        return OrdenS;
    }
    
    private static byte[] orden(int e){
        byte[] OrdenE = new byte[4];
        
        for(int i=0; i < 4; i++){
            OrdenE[i] = (byte) e;
            e = e>>>8;
        }
        
        return OrdenE;
    }
    
    private static byte[] orden(long l){
        byte[] OrdenL = new byte[8];
        
        for(int i=0; i < 8; i++){
            OrdenL[i] = (byte) l;
            l = l>>>8;
        }
        
        return OrdenL;
    }
    
}
