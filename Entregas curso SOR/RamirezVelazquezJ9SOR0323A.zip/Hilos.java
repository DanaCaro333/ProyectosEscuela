
import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Frame;
import java.awt.TextArea;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.util.logging.Level;
import java.util.logging.Logger;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author danacaro
 */
public class Hilos extends Frame implements ActionListener, WindowListener {
    
    private TextArea a1, a2;
    private Button boton;
    private Manager h1, h2;
    
    
    public Hilos(){
        super("Hilos");
        
        setLayout(new BorderLayout());
        
        a1 = new TextArea();
        a2 = new TextArea();
        
        a1.setEditable(false);
        a2.setEditable(false);
        
        boton = new Button("Haz algo");
        
        add("North",a1);
        add("Center",a2);
        add("South",boton);
        
        addWindowListener(this);
        boton.addActionListener(this);
        
        h1 = new Manager(1000,a1);
        h2 = new Manager(2000,a2);
        
        setSize(400,400);
        
        h1.start();
        h2.start();
        
        addWindowListener(this);
    }
    
    public static void main(String[] args){
        Hilos h = new Hilos();
        h.setVisible(true);
        
    }
    
    class Manager extends Thread{
        private int contador;
        private long dormir;
        private TextArea area;
        public boolean detener;
        
        public Manager(long s, TextArea a){
            contador = 0;
            dormir = s;
            area = a;
            detener = false;
        }
        public synchronized void dormir(){
            detener =!detener;
        }
        
        public synchronized void despertar(){
            detener =!detener;
            notify();
        }
        
        public void run(){
            while(true){
                if(detener){
                    synchronized(this){
                        try {
                            sleep(dormir);
                        } catch (InterruptedException ex) {
                            Logger.getLogger(Hilos.class.getName()).log(Level.SEVERE, null, ex);
                        }  
                    }
                    
                }
                area.append(contador+"\n");
                contador++;
                try {
                    sleep(dormir);
                } catch (InterruptedException ex) {
                    Logger.getLogger(Hilos.class.getName()).log(Level.SEVERE, null, ex);
                }   
            }  
        }
    }
    @Override
    public void actionPerformed(ActionEvent ae) {
        if(h1.detener){
            h1.despertar();
        }else{
            h1.dormir();
        }
    }

    @Override
    public void windowOpened(WindowEvent we) {
    }

    @Override
    public void windowClosing(WindowEvent we) {
        System.exit(0);
    }

    @Override
    public void windowClosed(WindowEvent we) {
        
    }

    @Override
    public void windowIconified(WindowEvent we) {
    }

    @Override
    public void windowDeiconified(WindowEvent we) {
    }

    @Override
    public void windowActivated(WindowEvent we) {
    }

    @Override
    public void windowDeactivated(WindowEvent we) {
    }
    
}
